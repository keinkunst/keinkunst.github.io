// Hér kemur kóðinn þinn:

function setup() {
  createCanvas(400, 400);
  background(255,200,0);
  frameRate(4);
}

function draw() {
  fill(random(0,255));
  ellipse(200,200,50,50);
}
